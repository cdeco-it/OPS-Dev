<?php

	require_once('class.db.php');

	class Helper extends Db {

		function __construct(){
			parent::__construct();
		}

/****	DEFINER METHODS 	*****/

		public function defineEmployeeStatus($value){
			if($value == 1){
				return("Active");
			}else{
				return("Inactive");
			}
		}

/****	POPULATE METHODS 	*****/

		public function populatePrefix($value = NULL){
			$query = "SELECT * FROM common_prefix ORDER BY common_prefix_id ASC";
			$this->set($query);
			$this->execute();
			foreach($this->returnSet() as $row){
				if($row['common_prefix_id'] == $value){
					echo'<option value="'.$row['common_prefix_id'].'" selected="SELECTED">'.$row['common_prefix_desc'].'</option>';
				}else{
					echo '<option value="'.$row['common_prefix_id'].'">'.$row['common_prefix_desc'].'</option>';
				}
			}
		}

		public function populateSuffix($value = NULL){
			$query = "SELECT * FROM common_suffix ORDER BY common_suffix_id ASC";
			$this->set($query);
			$this->execute();
			foreach($this->returnSet() as $row){
				if($row['common_suffix_id'] == $value){
					echo '<option value="'.$row['common_suffix_id'].'" selected="SELECTED">'.$row['common_suffix_abbr'].'  ('.$row['common_suffix_desc'].')</option>';
				}else{
					echo '<option value="'.$row['common_suffix_id'].'">'.$row['common_suffix_abbr'].' ('.$row['common_suffix_desc'].')</option>';
				}
			}
		}

		public function populateStates($value = NULL){
			$query = "SELECT * FROM common_usstates ORDER BY common_usstates_id ASC";
			$this->set($query);
			$this->execute();
			foreach($this->returnSet() as $row){
				if($row['common_usstates_id'] == $value){
					echo '<option value="'.$row['common_usstates_id'].'" selected="SELECTED">'.$row['common_usstates_full'].'</option>';
				}else{
					echo '<option value="'.$row['common_usstates_id'].'">'.$row['common_usstates_full'].'</option>';
				}
			}
		}

		public function populateCountry($value = NULL){
			$query = "SELECT * FROM common_countries ORDER BY common_countries_id ASC";
			$this->set($query);
			$this->execute();
			foreach($this->returnSet() as $row){
				if($row['common_countries_id'] == $value){
					echo '<option value="'.$row['common_countries_id'].'" selected="SELECTED">'.$row['common_countries_proper'].'</option>';
				}else{
					echo '<option value="'.$row['common_countries_id'].'">'.$row['common_countries_full'].'</option>';
				}
			}
		}

		public function populateEmployeeStatus($value = NULL){
			$query = "SELECT * FROM employee_status ORDER BY employee_status_id ASC";
			$this->set($query);
			$this->execute();
			foreach($this->returnSet() as $row){
				if($row['employee_status_id'] == $value){
					echo '<option value="'.$row['employee_status_id'].'" selected="SELECTED">'.$row['employee_status_desc'].'</option>';
				}else{
					echo '<option value="'.$row['employee_status_id'].'" >'.$row['employee_status_desc'].'</option>';
				}
			}

		}

		//@TODO
		//
		public function populateEmployeeACL($value = NULL){

		}

		public function populateEmployeeSubscription($value = NULL){
			if($value != NULL && $value == 0){
				echo '<option value="0" selected="SELECTED">No</option>
						<option value="1"> Yes </option>';
			}

			if($value != NULL && $value == 1){
				echo '<option value="0" >No</option>
						<option value="1" selected="SELECTED"> Yes </option>';
			}

		}

/****	TIME & DATE METHODS 	*****/

		public function date_toStandard($value){
			$da = array('Y' => NULL, 'M' => NULL, 'D' => NULL);
			$valueX = explode("-", $value);
			$da['Y'] = $valueX[0];
			$da['M'] = $valueX[1];
			$da['D'] = $valueX[2];
			$standardDate = $da['M'].'-'.$da['D'].'-'.$da['Y']; 
			return $standardDate;
		}

		public function date_toSQL($value){
			$da = array('Y' => NULL, 'M' => NULL, 'D' => NULL);
			$valueX = explode("-", $value);
			$da['M'] = $valueX[0];
			$da['D'] = $valueX[1];
			$da['Y'] = $valueX[2];
			$sqlDate = $da['Y'].'-'.$da['M'].'-'.$da['D']; 
			return $sqlDate;
		}

/****	GENERATOR METHODS 	*****/

		public function generate_Password($value = NULL){
			if(is_null($value)){
				return($this->generate_RandomPassword());
			}else{
				$x = strtolower(substr($value['first'], 0, 1));
				$y = strtolower(substr($value['last'], 0, 1));
				$d = explode("-", $value['dob']);
				$z = $d[0].$d[1].substr($d[2], -2);
				$plain = $x.$y.$z;
				$hash = password_hash($plain, PASSWORD_BCRYPT);
				$password = array("plain" => $plain, "crypt" => $hash);
				return($password);
			}
		}

		public function generate_RandomPassword(){
			$x = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
			$random = array();
			$len = strlen($x) - 1;
			for($i = 0; $i < 8; $i++){
				$n = rand(0, $len);
				$random[] = $x[$n];
			}
			$final = implode($random);
			$password = array("plain" => $final, "crypt" => password_hash($final, PASSWORD_BCRYPT));
			return($password);
		}

		public function generate_Username($value = NULL){
			if(is_null($value)){
				return(NULL);
			}else{
				//Set the basic username pattern...
				$f = strtolower($value['first']);
				$l = strtolower(substr($value['last'], 0, 1));
				$username = $f.$l;

				//First check to see if there are repeated names...
				$query = "SELECT COUNT(employee_username) AS count FROM employee WHERE employee_username = '$username'";
				$this->set($query);
				$result = $this->returnSingle();

				//If there are...then adjust the username with incremental addition to username
				if($result['count'] >= 1 ){
					$mod = $result['count']++;
					$username = $f.$l.$mod;
				}
				return($username);
			}
		}


/****	FORMATTER METHODS 	*****/
		//@TODO 
		//WILL FINISH...
		public function format_PhoneNumber($value = NULL){
			if(is_null($value)){
				return(NULL);
			}else{

				//Remove everything by the digits
				$number = preg_replace("/[^d]/","", $value);
				
				//Get the lenght of the number so we can figure out how to format
				$len = strlen($number);

				//Consider format 1-xxx-yyy-zzzz
				if($len == 11){

				}

				//Consider format xxx-yyy-zzzz
				if($len == 10){

				}

			}
		}
	}
?>