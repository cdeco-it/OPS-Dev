<?php

//require_once('../lib/class/class.employee.php');
//require_once('../lib/class/class.helper.php');

echo $_SERVER["DOCUMENT_ROOT"];

include_once($_SERVER["DOCUMENT_ROOT"].'/lib/class/class.db.php');

?>