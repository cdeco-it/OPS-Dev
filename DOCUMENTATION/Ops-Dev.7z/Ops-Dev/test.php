<?php

require_once('includes/class.employee.php');

$employee = new Employee();

//$query = 'SELECT name, meaning, gender FROM names ORDER BY name';

$employee->getEmployeeById(1);

echo $employee->getId();


/*


$employee->set($query);
$employee->execute();
echo '<br />'.$employee->rowCount();

echo '<pre>';
print_r($employee->returnSet());
echo '</pre>';

/*
require_once('includes/class.db.php');/
$db = new db();

$query = 'SELECT name, meaning, gender FROM names ORDER BY name';

echo $query.'<br />';

$db->query($query);
$db->execute();
echo '<br />'.$db->rowCount();

$resultSet = $db->returnSet();

echo '<pre>';
print_r($resultSet);
echo '</pre>';


$name = 'Oscar';
echo $name.'<br />';

$queryB ='SELECT name, gender FROM names WHERE name = :name';

$db->query($queryB);

$name = 'Jeff';
echo $name.'<br />';

$db->bindParam(':name', $name);

echo '<pre>';
echo $db->debug();
echo '</pre>';

$db->execute();

echo '<pre>';
print_r($db->returnSingle());
echo '</pre>';

echo '<br />'.$db->rowCount();
*/


?>